function changeContent() {
    alert("Welcome to the Programming World!");
    document.getElementById("info").innerHTML = `
        ✔ Programming allows us to solve problems creatively.<br>
        ✔ It's used to build websites, apps, games, and more.<br>
        ✔ You're now interacting with JavaScript events!<br>
    `;
}
